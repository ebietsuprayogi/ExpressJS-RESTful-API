var express = require('express');
var crypto =require('crypto');
var User = require('../models/user');
var Auth_mdw=require('../middlewares/auth');
var router = express.Router();
var secret='framework';
var session_store;


exports.index=function(req, res, next) {
    session_store=req.session;
      res.render('index', { title: 'Express',session_store:session_store });
  }

exports.login=function(req,res,next){
  res.render('login');
}

exports.checklogin = function(req, res,next){
  session_store = req.session;
  var password = crypto.createHmac('sha256', secret).update(req.param('password')).digest('hex');

    if(req.param('email') == "" || req.param('password') == "")
      {
      req.flash('info','Pun10, Tidak boleh ada field yang kosong!');
      res.redirect('/login');
      }
    else
      {
      User.find({ email: req.param('email'), password:password }, function(err, user){
          if (err) throw err;

          if (user.length > 0)
          {
              session_store.email = user[0].email;
              session_store.logged_in = true;

              res.redirect('/');
          }
          else
          {
              req.flash('info', 'Sepertinya akun Anda salah!');
              res.redirect('/login');
          }
      });
  }
}
  exports.logout=function(req,res,next){
    req.session.destroy(function(err){
        if(err){
          console.log(err);
        }
        else{
          res.redirect('/login');
        }
    });
  }


/*
exports.demo1 = function(req, res, next){
    res.render(
        'demo1',
        {
            message: 'Welcome to Express.js',
            user: {name:'Ebiet Suprayogi', email:'ebietsy@outlook.co.id',
            website: 'https://spaceapp.tech'}
        }
    );
}

exports.demo2 =function(req, res, next){
    res.render('demo2',
    {
        id: req.params.id,
        category: req.params.category,
    });
}

exports.demo3 = function(req, res, next){
    res.render('demo3');
}

exports.demo4 = function(req, res, next){
    res.json(
        {
            message: "request POST isExecuted",
            data: {
                username: req.param('username'),
                email: req.param('email'),
                website: req.param('website'),
                phone: req.param('phone'),
            }
        }
    );
}

exports.demo7 = function(req, res, next){
    res.render('demo7');
}

exports.demo8 = function(req, res, next){
    res.render('demo8');
}


//latihan
exports.latihan = function(req, res, next){
    res.render('latihan', { title: 'Express.js' });
}

exports.profile = function(req, res, next){
    res.render(
        'profile',
        {
            message: 'Welcome to Express.js',
            user: {name:'Ebiet Suprayogi', email:'ebietsy@outlook.co.id',
            website: 'https://spaceapp.tech'}
        }
    );
}

exports.contact = function(req, res, next){
    res.render('contact');
}

exports.contact_result = function(req, res, next){
    res.render(
        'contact_result',
        {
            email: req.param('email'),
        }
    );
}*/