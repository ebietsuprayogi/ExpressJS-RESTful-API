var express = require('express');
var crypto =require('crypto');
var User = require('../models/user');
var Auth_mdw=require('../middlewares/auth');
var router = express.Router();
var secret='framework';
var session_store;


let index=require('../controllers/index')
/* GET home page. */
router.get('/',Auth_mdw.check_login,index.index);
router.get('/login', index.login);
router.post('/checklogin',index.checklogin);
router.get('/logout', index.logout);

//router.get('/register', index.register);
/*
//Routing demo 1
router.get('/demo1', index.demo1);
//Routing demo 2
router.get('/demo2/(:id)/(:category)', index.demo2);
//Routing demo 3
router.get('/demo3', index.demo3);
//Routing demo 4
router.post('/demo4', index.demo4);

//Routing demo 7
router.get('/demo7', index.demo7);
//Routing demo 8
router.get('/demo7_result', index.demo8);


//latihan
router.get('/latihan', index.latihan);
//profile
router.get('/profile', index.profile);
//contact
router.get('/contact', index.contact);
//contact form
router.post('/contact_result', index.contact_result);
*/


module.exports = router;
