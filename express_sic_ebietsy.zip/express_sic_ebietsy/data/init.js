var mongoose = require('mongoose');
var crypto = require('crypto');

var secret = 'framework';
var password = crypto.createHmac('sha256', secret).update('123123aa').digest('hex');

console.log("Password: " + password);

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/dbietsy');

var User = require('../models/user');

User.find({email:'ebietsy@outlook.co.id'}, function (err, user){
    if (user.length == 0)
    {
        var admin = new User({
            email: 'ebietsy@outlook.co.id',
            password: password,
        });

        admin.save(function(err) {
            if (err) throw err;

            console.log('Admin is created!')
        });
    }
});